p1 = [1/62.8718 1]
p2 = [1/(62.8718^2) 0.445/62.8718 1]
p3 = [1/(62.8718^2) 1.247/62.8718 1]
p4 = [1/(62.8718^2) 1.802/62.8718 1]

p = conv(p1, p2)
p = conv(p, p3)
p = conv(p, p4)
syms s z
butter_filter(s) = 1/poly2sym(p,s)

H(z) = butter_filter(2*720*((1 - z^-1)/(1 + z^-1)))
F = [0.01:0.1:50]
omega = 2*pi*F

w = omega/720
h = double(H(exp(j * w)))
h_db = 20 * log10(abs(h))

plot(F, h_db)
title("Bode Plot")
xlabel("Frequency[Hz]")
ylabel("Mangitude[dB]")